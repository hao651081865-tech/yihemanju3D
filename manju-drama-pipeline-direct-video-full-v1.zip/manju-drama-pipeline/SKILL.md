---
name: manju-drama-pipeline
description: 将中文小说、网文大纲、章节正文或正式剧本转为可连续制作的 AI 漫剧生产包，并把主要角色打造为有灵魂、可持续运营的动漫 IP。支持 `STEPWISE` 四板块确认与 `FULL_PIPELINE` 一条龙，也支持将锁定剧本直接交付为含音色词、时码、景别机位、氛围色彩、构图、情绪表演、台词、音效和出口帧的可复制生视频完整版。用于长篇分块、首次开发、单集/批次生产、续接、审稿、合规修订和导演组交接。
---

# 漫剧工作室流水线

把用户提供的小说或剧本变成“小说事实锁 → 主角灵魂 IP → IP 驱动剧本锁稿 → 其他生产资产 → 黑白故事版 → Seedance 视频描述词”的可执行生产包。主 IP 不只是脸、服装与道具：先建立角色欲望、恐惧、关系、行为、情绪和视觉记忆点，再让它们指导剧本中的台词、动作、关系和角色弧线。技能有两个入口：`STEPWISE` 必须分板块确认，`FULL_PIPELINE` 才是一条龙；进入视频层后，`DIRECT_VIDEO_FULL` 可将已锁内容整合为每段一条可直接投喂的视频提示词。用户没有明确入口时，默认采用 `STEPWISE / NOVEL_TO_MAIN_IP`，不要擅自越过确认门禁。

## 何时直接触发

当用户粘贴中文小说、章节、大纲、剧本，或要求提炼漫剧主角 IP、角色灵魂、角色记忆点、场景/道具、生图提示词、短剧故事圣经、分集卡点、正式剧本、审稿合规、分镜、故事版、Seedance 视频提示词时使用本技能。用户可以直接贴正文并说“先做主角 IP”“确认 IP 后改剧本”“剧本确认后补资产”“进入视频分镜板块”“直接出视频”“发可直接投喂的完整版”或“按工作室完整流程 / 一条龙”。

## 双入口工作流

先读取 [workflow-entry-modes.md](references/workflow-entry-modes.md)，再路由任务：

- `STEPWISE`：只执行用户指定的一个板块。默认首板块为 `NOVEL_TO_MAIN_IP`；完成后明确停在确认门，不生成下一板块内容。
- `FULL_PIPELINE`：同一调用内依次完成四个板块；保留 IP、Agent 3/4 与资产生产状态门禁，但不等待用户逐板确认。
- 旧的细粒度 `【模式】` 仍可用；它们属于某个板块，不能绕过上游输入与门禁。

## 输入解析

识别用户给出的字段；缺失字段不要为了表单完整而追问：

```text
【工作流】STEPWISE | FULL_PIPELINE；缺失时默认 STEPWISE
【板块】NOVEL_TO_MAIN_IP | SCRIPT_ADAPTATION | PRODUCTION_ASSETS | VIDEO_DIRECTION；仅 STEPWISE 必填，缺失时默认 NOVEL_TO_MAIN_IP
【模式】ORCHESTRATE | P1_CHUNK | P2_MERGE | STORY_ANALYSIS | BIBLE_ONLY | BIBLE_SUMMARY | EPISODE_PLAN_ONLY | SCRIPT_ONLY | REVIEW_ONLY | COMPLIANCE_ONLY | SCRIPT_REVISION | DIRECTOR_HANDOFF | PREPRODUCTION | ASSETS_ONLY | STORYBOARD_ONLY | SEEDANCE_ONLY | DIRECT_VIDEO_FULL | CONTINUE_BATCH | REVISION_PATCH；兼容旧写法 FULL_PIPELINE
【项目名称】可选
【处理范围】可选，如“第一章”“第 1 集”或“第 1～4 段”
【批次大小】可选，默认 3～5 个视频段
【交付档案】QUICK | STUDIO，默认 QUICK
【故事版档案】CLEAN_GRID | TECHNICAL_ANNOTATED | BOTH，默认 BOTH（STUDIO）或 CLEAN_GRID（QUICK）；BOTH 是同一镜头链的两种渲染表述，不是两套分镜
【已有材料】故事圣经/集卡/剧本/审核报告/合规报告/导演交接包，均可选
【已有资产/上一批交接卡/上一段末帧】可选
【项目视觉硬约束】可选
【画幅】HORIZONTAL_16_9 | VERTICAL_9_16，默认 HORIZONTAL_16_9
【爆点前置】OFF | ON_SOURCE_ONLY，默认 OFF
【首集开场】AUTO | A | B | C，默认 AUTO
【小说正文】或【正式剧本】
```

用户在已进入 `VIDEO_DIRECTION` 后说“直接出视频”“直接投喂”“完整版”“不要修正版”时，自动采用 `DIRECT_VIDEO_FULL`。它是视频层交付形式，不绕过剧本与资产确认门禁。

推荐调用：

```text
【工作流】STEPWISE
【板块】NOVEL_TO_MAIN_IP
【小说正文】……
```

```text
【工作流】STEPWISE
【板块】SCRIPT_ADAPTATION
【已确认材料】主IP确认包
【确认语】确认主IP板块，进入小说改编剧本板块
```

```text
【工作流】FULL_PIPELINE
【小说正文】……
```

从文件名、章节名或主线生成简短项目名；从原文保守推断类型、时代和视觉方向，标为“合理补足设定”。不得编造人物关系、世界观规则、剧情结果或台词。用户说“按样例格式”“按镇龙棺格式”“完整前期”时，切换 `STUDIO` 档案。

| 模式 | 交付 |
| --- | --- |
| `FULL_PIPELINE` | 全篇事实 + 主角色 IP + IP 驱动的集数路线/本集锁稿 + 其他生产资产、分镜/故事版、Seedance 包 |
| `ORCHESTRATE` | Agent 0 当前阶段、缺失材料、下一 Agent 输入包、版本与风险，不越权写内容 |
| `P1_CHUNK` / `P2_MERGE` | 长篇分块忠实摘要 / 多块全局合并与待核对项 |
| `STORY_ANALYSIS` | Agent 1 主线、因果、人物、爆点、视觉重点与下游交接 |
| `BIBLE_ONLY` / `BIBLE_SUMMARY` | Agent 1.5 完整故事圣经 / Agent 1.55 的 20%—35%核心摘要 |
| `EPISODE_PLAN_ONLY` | Agent 1.6 分集规划、付费卡点与 27 项详细集卡 |
| `SCRIPT_ONLY` / `SCRIPT_REVISION` | Agent 2 正式剧本和自审 / 仅按审核或合规指令修订的版本 |
| `REVIEW_ONLY` / `COMPLIANCE_ONLY` | Agent 3 剧本医生报告 / Agent 4 合规报告和保张力替换建议 |
| `DIRECTOR_HANDOFF` | 双门禁通过后的锁定剧本与导演组交接包 |
| `PREPRODUCTION` | 完整故事圣经、分集规划、剧本锁稿和资产前瞻，不展开导演/视频层 |
| `ASSETS_ONLY` / `STORYBOARD_ONLY` / `SEEDANCE_ONLY` | 指定范围的后期生产层；必须挂载已锁定的剧本和前层资产 |
| `DIRECT_VIDEO_FULL` | 已锁定视频段的直接生视频完整版：每段一条自包含提示词，含时码镜头、景别机位、色彩氛围、构图、情绪表演、固定音色词、正式台词、音效与出口帧 |
| `CONTINUE_BATCH` / `REVISION_PATCH` | 依据上一批交接卡续做 / 只替换目标段与受影响交接字段 |

| 工作流 / 板块 | 允许输出 | 强制停止点 |
| --- | --- | --- |
| `STEPWISE / NOVEL_TO_MAIN_IP` | P1/P2 事实锁、S/A 主角色灵魂 IP、主角色 `CHAR/VOICE/LOOK`、关系动力与记忆点 | 等待用户确认主 IP；不得输出故事圣经、集卡、正式剧本、场景/道具资产、分镜或 Seedance |
| `STEPWISE / SCRIPT_ADAPTATION` | Agent 1—4、IP 驱动故事圣经、分集卡、锁定剧本、导演交接包 | 等待用户确认剧本；不得输出场景/道具等其他生产资产、分镜或 Seedance |
| `STEPWISE / PRODUCTION_ASSETS` | 非主角生产资产：场景、道具、群像、次要角色、剧本专属 LOOK、调用表与 P0/P1/P2 清单 | 等待用户确认生产资产；不得输出导演分镜或 Seedance |
| `STEPWISE / VIDEO_DIRECTION` | 分段、导演分镜、故事版、Seedance 描述词、交接卡 | 必须挂载锁定剧本和确认资产；无 `APPROVED_R01` 时只交付预演 / 待确认视频描述词 |
| `FULL_PIPELINE` | 上述四板块按顺序的一条龙生产包 | 仅在文本产物内自动继续；不得伪造真实资产图已确认 |

## 角色流程与门禁

严格采用下面顺序；`FULL_PIPELINE` 可以把未被用户指定的上游文件压缩展示，但不能跳过事实、主 IP、审稿和合规判断。`STEPWISE` 只在当前板块内运行到门禁，必须停止：

1. **事实锁 → P1/P2（长篇时）。** 先按原文顺序建立 `E1 → E2 → E3` 事件账本，锁定原因、动作、结果、人物目标、必要铺垫、可压缩项和字符范围；超长或分多次提供的小说再按块忠实摘要、全局合并。未提供的后续只能写“原文暂未明确/暂未提供”。
2. **主角色灵魂 IP。** 先读 [ip-soul-bible.md](references/ip-soul-bible.md)，只为 S/A 主角色建立 `SOUL`、主 `CHAR`、必要 `LOOK`、`VOICE`、关系动力、视觉/行为记忆点和主角色身份锚定套件。这个阶段依据原文事实，不写故事圣经或正式剧本；用户确认主 IP 后才能改编剧本。
3. **Agent 1 → 1.5 → 1.55。** 在已确认主 IP 的约束下，完成主线深度提炼、完整故事圣经、20%—35%核心摘要；锁定人物关系、世界观、信息释放、伏笔和禁改项。主 IP 只影响角色表达，不得覆盖原文事实。
4. **Agent 1.6。** 给容量诊断、分集总表、付费卡点及每集 27 项结构卡。第 1 集/投流开场需要按档案输出或内部比较 A/B/C 三种不同切入结构；`ON_SOURCE_ONLY` 只允许使用已提供原文的来源事件，且必须回到 E1 顺叙。总表和详细卡的剧情范围都要写 `原文字符范围：XXXX-YYYY`；超过 10 集时默认只展开第 1—5 集或用户指定批次。
5. **Agent 2。** 依据锁定集卡和确认的 `SOUL` 写 60—120 秒正式剧本，并给执行确认、观众/心理钩子、时长预算、因果链、自审和下一集交接。默认台词驱动、无旁白/OS：原文叙述优先转为可见动作、道具证据、环境变化或必要对白；只删重复/寒暄，不删前提、转折、反驳、承接、条件、决定或证据。用户明确允许旁白时才可使用。
6. **Agent 3 → Agent 2 修订（如需）→ Agent 4 → Agent 2 安全修订（如需）。** Agent 3 只做剧本质量诊断和局部示例；Agent 4 只做文字层风险审查与保张力的安全替代表达。任何返修均仅改受影响内容，必要时回交 Agent 3 复核。
7. **锁定导演交接包。** 只有 Agent 3 与 Agent 4 都已通过或完成要求的小修后，才能把该版本作为其他生产资产、Agent 6/7 的正式依据。
8. **其他生产资产 → Agent 6 → Agent 7。** 剧本确认后再补场景、道具、群像、次要角色和剧本专属 LOOK；随后导演分镜/故事版，最后 Seedance。每段目标 12—15 秒，绝不超过 15 秒。

`STEPWISE` 的板块门禁：

1. **小说事实 / 主 IP 板块。** 只完成步骤 1—2，输出“主 IP 确认包”；用户未明确说“确认主IP板块，进入小说改编剧本板块”前，禁止输出故事圣经、集卡、正式剧本、场景/道具资产、分镜、故事版或 Seedance。
2. **小说改编剧本板块。** 只完成步骤 3—7，必须使用已确认 `SOUL` 指导人物表达，输出“剧本确认包”；用户未明确说“确认剧本板块，进入其他资产提取板块”前，禁止补场景、道具、群像、次要角色资产、分镜、故事版或 Seedance。
3. **其他生产资产板块。** 只完成剧本锁定后的 Agent 5 增量生产资产：场景、道具、群像、次要角色和必要 `LOOK`；主角色 `CHAR/SOUL` 默认复用，不得重建。用户未明确确认生产资产前，禁止进入 Agent 6/7。
4. **视频分镜头描述词板块。** 只在已锁剧本与确认主 IP / 生产资产的基础上完成 Agent 6→7；无已生成确认图时，标为 `TEXT_SPEC / P0_DRAFT` 预演包，不得声称已可正式生成视频。

`FULL_PIPELINE` 在同一调用内依次完成以上四板块；以“自动衔接记录”代替逐板等待，但仍要显式写出主 IP、剧本门禁、生产资产状态和未确认项。

不把未通过 Agent 3 和 Agent 4 的草稿当作导演、资产或 Seedance 的正式依据。合规报告是创作风险筛查与改写建议，不替代法律意见或平台终审。

## 读取分层参考

按任务读取，不要把所有原始提示词塞入同一次上下文：

- 剧本组流程、字段、版本和导演交接：先读 [scriptroom-workflow.md](references/scriptroom-workflow.md)；需要严格复刻某 Agent 的原始字段时，再读 `references/scriptroom-source/agent-*-source.txt`。
- 工作流入口、四板块输入输出、确认语和阻断条件：先读 [workflow-entry-modes.md](references/workflow-entry-modes.md)。
- 角色灵魂 IP、角色记忆点、身份锚定、状态连续性与群像防克隆：主 IP 板块先读 [ip-soul-bible.md](references/ip-soul-bible.md)；其他生产资产板块只复用其已锁主 IP。
- 资产层：先读 [prompt-standards.md](references/prompt-standards.md)，需要原始字段或边界时再读 `references/agent-5-source.txt`。
- 导演层：先读 [prompt-standards.md](references/prompt-standards.md)，需要镜头、站位或故事版模板时再读 `references/agent-6-source.txt`。
- 视频层：先读 [prompt-standards.md](references/prompt-standards.md)，需要表演、节拍或 Seedance 模板时再读 `references/agent-7-source.txt`。
- 用户要“直接出视频”“完整版”“不要修正版”时，额外读 [direct-video-full.md](references/direct-video-full.md)，按 `DIRECT_VIDEO_FULL` 交付。
- 需要批次交接、资产卡、导演包或视频包的完整模板时，读 [workflow-and-output-contract.md](references/workflow-and-output-contract.md)。
- 用户要求“按样例格式”“按镇龙棺格式”或 `STUDIO` 时，读 [real-output-formats.md](references/real-output-formats.md)。
- 首次开发、首集/投流开场、横竖屏适配、台词功能审计、参考图映射、生成失败或重试时，读 [retention-and-production-enhancements.md](references/retention-and-production-enhancements.md)。

## 全局连续性规则

- 冲突按：用户硬约束 → 故事圣经禁改项 → 已通过的风险降级要求 → Agent 1.6 集卡/卡点 → 已锁定正式剧本/原文事实 → 已确认资产 → 上一批交接卡/末帧 → 保守合理补足。冲突要写明来源、影响、采用方案和返修对象。
- 所有资产使用 `STYLE`、`CHAR`、`LOOK`、`SET`、`PROP`、`GROUP`、`VOICE` 编号；角色灵魂档案使用 `SOUL_[角色名]_V1`。基础角色只建一个 `CHAR`；仅为长期、高频或剧情关键状态建少量 `LOOK`。`SOUL` 锁人物内在和表达方式，不是新增剧情或替代视觉资产。
- 场景必须用北/南/东/西、中央活动区、主/次入口和固定物做空间锚点；不得只说“画面左/右”。
- 角色、服装层级、发型、脸型、饰品、固定道具、场景结构、光线来源、摄影轴线和道具状态必须可追踪；任何新状态或新资产都要显式登记。
- 每张参考图都要声明职责：`REF-CHAR/LOOK` 锁身份，`REF-SET` 锁空间和光源，`REF-PROP` 锁结构和状态，姿势图只锁骨架，风格图不覆盖身份。首尾帧至少继承位置/朝向、手部/道具、机位/轴线、光线/情绪中的三项。
- 资产生产状态使用 `TEXT_SPEC → P0_DRAFT → APPROVED_R01`。未达 `APPROVED_R01` 的资产只能用于文字/故事版预演，正式 Seedance 包必须明确其待确认状态。
- Agent 2 中的 `【字幕】` 是剧本文字/后期提示；进入资产、故事版和 Seedance 层时，一律转为“后期文字叠加备注”，不得要求模型生成可读中文。
- `CLEAN_GRID` 为黑白灰阶、无文字/字幕/对白框/水印的实际生图提示词；`TECHNICAL_ANNOTATED` 可有 `EYE`、`PUSH`、`TRACK`、`FOCUS`、`EXIT` 等短英文标签和导向箭头，中文导演批注写在图外。视频无字幕、对白框、水印、背景音乐、多余人物和现代元素。
- `DIRECT_VIDEO_FULL` 必须是完整替换稿，不使用“修正版”“补丁”“仅改动项”作为交付结构。固定 `VOICE` 音色词先全局锁定，再逐句置于台词前；每段提示词自包含时码、镜头、表演、光线、声音和出口帧。

## 默认交付结构

完整字段与模板以参考文件为准。按模式交付所需层，`FULL_PIPELINE` 的最低包如下：

1. **小说事实与主角色 IP 包**：输入范围、画幅/爆点前置开关、全篇事实地图与事件账本、S/A 角色的 `SOUL/CHAR/VOICE/LOOK`、关系动力、行为/视觉记忆点、版本与未确认项。
2. **IP 驱动锁定剧本包**：核心圣经摘要、分集总表、本集 27 项集卡、第 X 集正式剧本、时长/因果/动机/钩子自审、Agent 3 评级与修改记录、Agent 4 合规结论与修改记录；`STUDIO` 时完整展开所有上游文档。
3. **导演组交接包**：项目/集数/最终版本、采用的主 IP 版本、Agent 3/4 状态、核心摘要、本集集卡、最终剧本、人物状态、释放/隐藏信息、伏笔/道具、合规提醒、导演禁止项、重点表现和下一集承接。
4. **其他生产资产包**：段落路线、时长、剧情功能、已复用的角色灵魂 IP、资产调用表、风格卡、场景/道具/群像/次要角色/剧本专属 `LOOK`、优先级、生产状态与禁止变化项。
5. **导演包**：逐段剧本范围、导演意图、站位平面图、摄影轴线、逐镜六列技术分镜表、表演、故事版提示词、图外导演批注、出口帧和 Agent 7 执行卡。
6. **Seedance 包与下一批交接卡**：每段一条提示词、4—8 个合计等于段长的节拍，以及末帧、位置/朝向/情绪、轴线、光线、道具状态、未完成动作/台词和首镜承接。`DIRECT_VIDEO_FULL` 时将这些字段写进每段自包含的完整生视频提示词，并单列固定音色词与出口帧。

`STEPWISE` 不使用上述最低全包，而按当前板块交付。每个板块收尾必须列出“已完成、锁定版本、下一板块所需输入、不可越过项”和一条明确确认语。

## 交付前自检

- 是否先覆盖用户提供的完整范围，再展开本集或本批？长篇是否正确使用 P1/P2，未提供内容是否没有被补写为事实？
- 是否建立并保持 `E1 → E2 → E3` 原文顺序？`ON_SOURCE_ONLY` 是否只使用已提供事件、标注来源与剧透风险，并自然回到 E1？
- 是否按画幅完成构图与前 3—5 秒留存设计？台词是否只删除 X 类重复，并保留所有必要因果功能？
- 是否每集都具备 27 项结构卡和准确 `原文字符范围：XXXX-YYYY`，且没有按原著章节机械切集？
- 正式剧本是否有 60—120 秒预算、场景因果、角色动机、钩子与交接包？
- Agent 3 是否以 `综合评级：X` 收尾；B/C/D 是否提供 `修改指令：`？Agent 4 是否以 `合规结果：` 收尾；非“通过”是否提供 `合规修改指令：`？
- 是否只让已完成剧本医生与合规门禁的最终剧本进入资产、分镜和 Seedance？
- 是否每段不超过 15 秒，且没有切断台词、动作、反应或关键信息？
- 是否每项资产都有稳定编号、调用范围和禁止变化项，且没有滥建 LOOK？
- 是否每段有初始站位、轴线、镜头功能、逐镜技术表、表演微动作、出口帧和下一段承接？
- 是否每段只建立一条多格黑白故事版镜头链；若为 `BOTH`，两种提示词是否严格对应同一镜头链，且视频节拍时间之和等于段长？
- `DIRECT_VIDEO_FULL` 是否逐段提供一条可复制的完整生视频提示词，含 4—8 个连续时码节拍、景别/机位/构图、可见情绪表演、逐句固定音色词、正式台词、音效、无背景音乐和出口帧，且未以“修订/补丁”替代完整内容？
- 若为 `REVISION_PATCH` 或 `SCRIPT_REVISION`，是否只修改目标内容及其受影响交接字段，并明确其他内容未修改？
- 关键段生成失败时，是否先按资产/分镜/提示词/参数/后期定位，并提供“简化单动作”与“按落点拆段”两种重试？`STUDIO` 导演/Seedance 包是否运行 `scripts/audit_manju_production.py <生产包.md> --strict`？

输出结束时，用一句话提示用户：`继续下一批` 即可沿用交接卡续做。
