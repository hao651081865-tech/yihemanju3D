#!/usr/bin/env python3
"""Static lint for Agent 6/7 markdown production packs."""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path


SEGMENT_RE = re.compile(
    r"(?m)^#{2,4}\s+(?:(?:\d+\.\s*)?视频\s*\d+|第\s*\d+\s*段(?:\s*Seedance)?(?:\s*执行包)?)"
)
DURATION_RE = re.compile(r"(?:[｜|]\s*|时长\s*)(\d+(?:\.\d+)?)\s*秒")
BEAT_RE = re.compile(r"(?m)(\d+(?:\.\d+)?)\s*[—-]\s*(\d+(?:\.\d+)?)\s*秒?")


def issue(kind: str, message: str, bucket: list[str]) -> None:
    bucket.append(f"{kind}: {message}")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("path", type=Path, help="UTF-8 markdown production pack")
    parser.add_argument("--strict", action="store_true", help="Treat warnings as failures")
    args = parser.parse_args()

    try:
        text = args.path.read_text(encoding="utf-8-sig")
    except (OSError, UnicodeError) as exc:
        print(f"ERROR: cannot read {args.path}: {exc}")
        return 2

    errors: list[str] = []
    warnings: list[str] = []
    direct_video_full = bool(re.search(r"(?:【模式】\s*DIRECT_VIDEO_FULL|\bDIRECT_VIDEO_FULL\b)", text))
    segments = list(SEGMENT_RE.finditer(text))
    if not segments:
        issue("ERROR", "未检测到“视频 XX”或“第 X 段”段落标题。", errors)

    if not re.search(r"原文(?:字符)?范围", text):
        issue("WARNING", "未检测到原文范围；无法追溯改编边界。", warnings)

    if direct_video_full:
        if "全局固定视频约束" not in text:
            issue("ERROR", "DIRECT_VIDEO_FULL 缺少“全局固定视频约束”。", errors)
        if "音色词" not in text:
            issue("ERROR", "DIRECT_VIDEO_FULL 缺少固定音色词。", errors)
        if re.search(r"修订补丁|REVISION_PATCH|仅替换|其余不变", text):
            issue("ERROR", "DIRECT_VIDEO_FULL 不得以修订/补丁结构交付。", errors)

    for index, match in enumerate(segments, start=1):
        end = segments[index].start() if index < len(segments) else len(text)
        block = text[match.start() : end]
        label = f"第{index}段"
        duration_match = DURATION_RE.search(block[: match.end() - match.start() + 80])
        duration = float(duration_match.group(1)) if duration_match else None

        if duration is None:
            issue("WARNING", f"{label}未检测到段长。", warnings)
        elif duration > 15:
            issue("ERROR", f"{label}时长 {duration:g} 秒，超过 Agent 6/7 的 15 秒上限。", errors)

        if direct_video_full:
            required = {
                "挂载参考": ("挂载参考",),
                "完整生视频提示词": ("完整生视频提示词",),
                "出口帧": ("出口帧",),
            }
        else:
            required = {
                "导演卡/导演意图": ("导演执行卡", "导演意图"),
                "故事版": ("故事版",),
                "视频节拍": ("视频节拍",),
                "完整 Seedance 提示词": ("完整 Seedance",),
                "出口帧": ("出口帧",),
            }
        for name, phrases in required.items():
            if not any(phrase in block for phrase in phrases):
                issue("ERROR", f"{label}缺少{name}。", errors)

        beat_start = block.find("【视频节拍】")
        prompt_start = block.find("【完整 Seedance")
        if direct_video_full:
            beat_text = block
        elif beat_start >= 0 and prompt_start > beat_start:
            beat_text = block[beat_start:prompt_start]
        else:
            beat_text = ""
        if beat_text:
            beats = [(float(a), float(b)) for a, b in BEAT_RE.findall(beat_text)]
            if len(beats) < 4 or len(beats) > 8:
                issue("WARNING", f"{label}检测到 {len(beats)} 个节拍，建议为 4—8 个。", warnings)
            if beats:
                if abs(beats[0][0]) > 0.15:
                    issue("WARNING", f"{label}首个节拍未从 0 秒开始。", warnings)
                for previous, current in zip(beats, beats[1:]):
                    if abs(previous[1] - current[0]) > 0.15:
                        issue("WARNING", f"{label}节拍 {previous} 与 {current} 不连续。", warnings)
                if duration is not None and abs(beats[-1][1] - duration) > 0.15:
                    issue("ERROR", f"{label}节拍末尾 {beats[-1][1]:g} 秒，与段长 {duration:g} 秒不一致。", errors)

        if "无背景音乐" not in block and "禁止背景音乐" not in block:
            issue("WARNING", f"{label}未明确无背景音乐。", warnings)
        if "口型" not in block and "台词" not in block:
            issue("WARNING", f"{label}未检测到台词或口型执行要求。", warnings)
        if direct_video_full and "音色词" not in block:
            issue("ERROR", f"{label}缺少逐句音色词。", errors)

    print(f"文件：{args.path}")
    print(f"检测到视频段：{len(segments)}")
    for message in errors + warnings:
        print(message)
    if not errors and not warnings:
        print("PASS: Agent 6/7 生产包结构检查通过。仍需人工检查剧情、表演、合规和成片。")
    elif not errors:
        print("PASS WITH WARNINGS: 硬结构通过，请处理警告。")
    return 1 if errors or (args.strict and warnings) else 0


if __name__ == "__main__":
    sys.exit(main())
